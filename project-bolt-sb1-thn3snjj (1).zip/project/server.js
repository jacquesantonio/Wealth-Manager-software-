import express from 'express';
import cors from 'cors';
import Stripe from 'stripe';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config();

const app = express();
const stripe = new Stripe('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');

const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:3000',
  'https://expertcareerguidance.info'
];

app.use(cors({
  origin: function(origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.indexOf(origin) === -1) {
      const msg = 'The CORS policy for this site does not allow access from the specified Origin.';
      return callback(new Error(msg), false);
    }
    return callback(null, true);
  },
  methods: ['GET', 'POST'],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

app.get('/', (req, res) => {
  res.json({ status: 'API is running' });
});

app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const { productId } = req.body;
    
    if (!productId) {
      return res.status(400).json({ error: 'Product ID is required' });
    }

    const amount = getAmountFromProductId(productId);
    if (!amount) {
      return res.status(400).json({ error: 'Invalid product ID' });
    }

    // Create Stripe session directly with the amount
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: 'Career Consultation Session',
            },
            unit_amount: amount,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${process.env.DOMAIN || 'http://localhost:5173'}/success`,
      cancel_url: `${process.env.DOMAIN || 'http://localhost:5173'}/cancel`,
    });

    res.json({ id: session.id });
  } catch (error) {
    console.error('Stripe error:', error);
    res.status(500).json({ 
      error: 'Payment session creation failed',
      details: error.message 
    });
  }
});

function getAmountFromProductId(productId) {
  const prices = {
    'prod_RiQHvWbNqLEsCK': 1500, // $15.00
  };
  return prices[productId];
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});