import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Calendar, Clock, DollarSign, Shield, GraduationCap, TrendingUp, Briefcase, CheckCircle, ArrowRight } from 'lucide-react';

// Initialize Stripe
const stripePromise = loadStripe('pk_live_51QobdOEybIVo4zUDdLIWo7IeB96WM0LubGxzhdnkOHVtYOtftjkUYA4oMR4NYZtVAmXsgb6dOAcq4Kf3HX3T2yfX00k3sDzGkQ');

// API URL based on environment
const API_URL = import.meta.env.PROD 
  ? 'https://expertcareerguidance.info'
  : 'http://localhost:3000';

declare global {
  interface Window {
    Calendly: any;
  }
}

function App() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [hoveredTier, setHoveredTier] = useState<string | null>(null);

  const consultationTier = {
    name: 'Quick Career Chat',
    price: 15,
    productId: 'prod_RiQHvWbNqLEsCK',
    duration: '20 minutes',
    calendlyUrl: 'https://calendly.com/jacquesantoniodorcean/30min',
    description: 'Perfect for initial career planning and quick insights.',
    features: [
      'Career path overview',
      'Quick resume review',
      'Industry insights',
    ],
    featured: true,
    color: 'blue',
  };

  const openCalendly = (url: string) => {
    window.Calendly.initPopupWidget({
      url: url,
    });
  };

  const handleBooking = async (tier: any) => {
    try {
      setIsProcessing(true);
      
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      const response = await fetch(`${API_URL}/api/create-checkout-session`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          productId: tier.productId,
        }),
      });

      const session = await response.json();
      
      if (session.error) {
        throw new Error(session.error);
      }

      const result = await stripe.redirectToCheckout({
        sessionId: session.id,
      });

      if (result.error) {
        throw new Error(result.error.message);
      }

      openCalendly(tier.calendlyUrl);
      
    } catch (error) {
      console.error('Payment error:', error);
      alert('Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Break Into Asset & Wealth Management</h1>
            <p className="text-xl text-blue-100 mb-8">Get personalized guidance from an industry professional to launch your finance career</p>
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <div className="bg-blue-800/50 px-4 py-2 rounded-full flex items-center backdrop-blur-sm">
                <GraduationCap className="h-5 w-5 mr-2" />
                Finance Graduate
              </div>
              <div className="bg-blue-800/50 px-4 py-2 rounded-full flex items-center backdrop-blur-sm">
                <Briefcase className="h-5 w-5 mr-2" />
                Finance Professional
              </div>
              <div className="bg-blue-800/50 px-4 py-2 rounded-full flex items-center backdrop-blur-sm">
                <Shield className="h-5 w-5 mr-2" />
                Career Mentor
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Pricing Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Book Your Session</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Get started with a personalized career consultation
          </p>
        </div>

        <div className="max-w-lg mx-auto mb-16">
          <div
            onMouseEnter={() => setHoveredTier(consultationTier.name)}
            onMouseLeave={() => setHoveredTier(null)}
            className={`relative bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-300 ${
              hoveredTier === consultationTier.name ? 'transform -translate-y-2 shadow-xl' : ''
            } ring-2 ring-blue-500`}
          >
            <div className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{consultationTier.name}</h3>
              <p className="text-gray-600 mb-6">{consultationTier.description}</p>
              <div className="flex items-baseline mb-6">
                <span className="text-5xl font-extrabold text-gray-900">${consultationTier.price}</span>
                <span className="text-gray-500 ml-2">/ session</span>
              </div>
              <div className="flex items-center text-gray-500 mb-6">
                <Clock className="h-5 w-5 mr-2" />
                <span>{consultationTier.duration}</span>
              </div>
              <ul className="space-y-4 mb-8">
                {consultationTier.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 mr-3 flex-shrink-0 mt-0.5 text-blue-500" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handleBooking(consultationTier)}
                disabled={isProcessing}
                className={`w-full py-4 px-6 rounded-xl flex items-center justify-center transition-all duration-300 text-white font-semibold
                  bg-blue-600 hover:bg-blue-700 focus:ring-blue-500
                  ${isProcessing ? 'opacity-50 cursor-not-allowed' : 'hover:shadow-lg'}
                  focus:outline-none focus:ring-2 focus:ring-offset-2`}
              >
                {isProcessing ? (
                  'Processing...'
                ) : (
                  <>
                    Book Session
                    <ArrowRight className="h-5 w-5 ml-2 transition-transform group-hover:translate-x-1" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Why Choose Section */}
        <div className="bg-white rounded-2xl shadow-lg p-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Why Work With Me</h3>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-transform hover:scale-110">
                <GraduationCap className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold mb-3">Industry Experience</h4>
              <p className="text-gray-600">Learn from real-world experience in asset & wealth management</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-transform hover:scale-110">
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold mb-3">Proven Success</h4>
              <p className="text-gray-600">Get guidance from someone who's successfully navigated the industry</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 transition-transform hover:scale-110">
                <Shield className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold mb-3">Personalized Approach</h4>
              <p className="text-gray-600">Receive tailored advice for your unique career goals</p>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm">© 2024 Career Advisory. All rights reserved.</p>
            <p className="text-sm mt-2 text-gray-400">Independent career guidance for educational purposes only.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;